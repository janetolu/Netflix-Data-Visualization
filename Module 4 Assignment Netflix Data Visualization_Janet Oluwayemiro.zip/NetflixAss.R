install.packages("ggplot2")
# Load necessary library
library(ggplot2)

# Load the dataset
data <- read.csv("Netflix_shows_movies_cleaned.csv")

# Create a bar plot for ratings distribution
ggplot(data, aes(x = rating)) +
  geom_bar(fill = "skyblue") +
  theme_minimal() +
  labs(title = "Distribution of Ratings", x = "Ratings", y = "Count")
